import * as bootstrap from 'bootstrap';
import _ from 'lodash';
